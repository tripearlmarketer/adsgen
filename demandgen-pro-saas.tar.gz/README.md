# DemandGen Pro

A comprehensive Google Ads Demand Gen campaign management platform built specifically for the Malaysian market.

## 🚀 Features

### Core Campaign Management
- **Campaign Creation & Management**: Full CRUD operations for Demand Gen campaigns
- **Ad Group Management**: Organize and optimize ad groups with advanced targeting
- **Ad Creative Management**: Handle responsive display ads with asset management
- **Asset Library**: Upload, organize, and optimize images and videos

### Malaysia-Specific Features
- **Prebuilt Audience Packs**: 4 Malaysia-focused audience segments
  - Perokok & Vape Malaysia
  - Imun & Gaya Hidup Sihat  
  - Pekerja Luar & Pemandu
  - Pasca-Sakit Recovery
- **Bilingual Support**: Bahasa Melayu and English interface
- **Local Currency**: MYR pricing and budgeting
- **Policy Compliance**: Built-in validation for Malaysian advertising regulations

### Advanced Automation
- **Smart Rules Engine**: Automated campaign optimization based on performance
- **A/B Testing**: Built-in experiment framework for campaign optimization
- **Alert System**: Real-time notifications for performance anomalies
- **Bulk Operations**: Efficient management of multiple campaigns

### Analytics & Reporting
- **Performance Dashboard**: Real-time campaign metrics and insights
- **Custom Reports**: Flexible reporting with export capabilities
- **Trend Analysis**: Historical performance tracking
- **ROI Optimization**: Advanced ROAS and CPA monitoring

## 🛠 Tech Stack

### Backend
- **Node.js** with **TypeScript**
- **Fastify** web framework
- **PostgreSQL** database
- **Redis** for caching and job queues
- **Google Ads API** integration
- **JWT** authentication

### Frontend
- **Next.js 14** with **React 18**
- **TypeScript** for type safety
- **Tailwind CSS** for styling
- **shadcn/ui** component library
- **TanStack Query** for data fetching
- **Framer Motion** for animations

### Infrastructure
- **Docker** containerization
- **Cloudways** deployment ready
- **BullMQ** for background jobs
- **Sharp** for image processing

## 📦 Installation

### Prerequisites
- Node.js 18+ 
- PostgreSQL 14+
- Redis 6+
- Google Ads API access

### Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd demandgen-pro
```

2. **Install dependencies**
```bash
npm install
```

3. **Environment setup**
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. **Database setup**
```bash
# Create database
createdb demandgen_pro

# Run migrations
npm run db:migrate

# Seed initial data
npm run db:seed
```

5. **Start development servers**
```bash
npm run dev
```

The API server will run on `http://localhost:8000` and the frontend on `http://localhost:3000`.

## 🔧 Configuration

### Environment Variables

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/demandgen_pro
PGUSER=your_pg_user
PGPASSWORD=your_pg_password

# Redis
REDIS_URL=redis://localhost:6379

# JWT
JWT_SECRET=your-super-secret-jwt-key

# Google Ads API
GOOGLE_ADS_DEVELOPER_TOKEN=your-developer-token
GOOGLE_ADS_CLIENT_ID=your-oauth-client-id
GOOGLE_ADS_CLIENT_SECRET=your-oauth-client-secret

# Application
NODE_ENV=development
PORT=8000
FRONTEND_URL=http://localhost:3000
```

### Google Ads API Setup

1. Create a Google Ads API application
2. Get your developer token
3. Set up OAuth2 credentials
4. Configure the environment variables

## 🚦 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/refresh` - Token refresh

### Campaigns
- `GET /api/campaigns` - List campaigns
- `POST /api/campaigns` - Create campaign
- `PUT /api/campaigns/:id` - Update campaign
- `DELETE /api/campaigns/:id` - Delete campaign

### Audiences
- `GET /api/audiences` - List audience packs
- `POST /api/audiences` - Create audience pack
- `POST /api/audiences/test` - Test audience reach

### Assets
- `POST /api/assets/upload` - Upload asset
- `GET /api/assets` - List assets
- `POST /api/assets/:id/variants` - Generate variants

### Automation
- `GET /api/rules` - List automation rules
- `POST /api/rules` - Create rule
- `POST /api/rules/:id/execute` - Execute rule

### Reports
- `POST /api/reports/run` - Generate report
- `GET /api/reports/dashboard/:accountId` - Dashboard data

## 🧪 Testing

```bash
# Run tests
npm test

# Run tests in watch mode
npm run test:watch

# Type checking
npm run type-check
```

## 📊 Database Schema

The application uses a comprehensive PostgreSQL schema with 15+ tables:

- **users** - User accounts and authentication
- **accounts** - Google Ads account connections
- **campaigns** - Campaign data and settings
- **ad_groups** - Ad group organization
- **ads** - Individual ad creatives
- **assets** - Media asset library
- **audience_packs** - Targeting configurations
- **rules** - Automation rules
- **experiments** - A/B testing data
- **reports** - Saved reports
- **alerts** - Performance alerts
- **audit_logs** - Complete audit trail

## 🔒 Security Features

- **JWT Authentication** with role-based access control
- **Password Hashing** with bcrypt
- **Rate Limiting** on API endpoints
- **Input Validation** with Zod schemas
- **SQL Injection Protection** with parameterized queries
- **CORS Configuration** for frontend integration

## 🌏 Malaysia Market Focus

### Audience Targeting
- Pre-configured audience segments for Malaysian demographics
- Local interest and behavior targeting
- Bahasa Melayu keyword integration

### Compliance
- Malaysian advertising policy validation
- Medical claim detection and blocking
- Culturally appropriate content guidelines

### Localization
- MYR currency formatting
- Asia/Kuala_Lumpur timezone
- Bilingual interface support

## 🚀 Deployment

### Cloudways Deployment

1. **Prepare build**
```bash
npm run build
```

2. **Environment setup**
- Configure production environment variables
- Set up PostgreSQL and Redis instances
- Configure Google Ads API credentials

3. **Deploy**
- Upload built application
- Run database migrations
- Start the application

### Docker Deployment

```bash
# Build image
docker build -t demandgen-pro .

# Run with docker-compose
docker-compose up -d
```

## 📈 Performance Optimization

- **Database Indexing** on frequently queried columns
- **Redis Caching** for API responses and session data
- **Image Optimization** with Sharp
- **Lazy Loading** for frontend components
- **Background Jobs** for heavy operations

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation

## 🔄 Changelog

### v1.0.0 (Current)
- Initial release
- Complete campaign management system
- Malaysia-specific audience packs
- Automation rules engine
- A/B testing framework
- Performance reporting
- Alert system

---

**DemandGen Pro** - Empowering Malaysian businesses with advanced Google Ads campaign management.
